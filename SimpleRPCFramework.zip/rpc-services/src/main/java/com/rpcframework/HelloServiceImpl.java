package com.rpcframework;

public class HelloServiceImpl implements HelloService {
    @Override
    public String sayHello(String msg) {

        //int i=1/0;   //模拟调用出错
        return "你好, " + msg;
    }

    @Override
    public Integer addNum(int a, int b) {

        return a+b;
    }
}