package com.rpcframework;

public interface HelloService {
    String sayHello(String name);

    Integer addNum(int a,int b);
}
