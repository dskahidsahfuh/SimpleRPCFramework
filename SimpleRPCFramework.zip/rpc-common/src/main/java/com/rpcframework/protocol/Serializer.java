package com.rpcframework.protocol;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;


import java.io.*;
import java.lang.reflect.Type;
import java.nio.charset.StandardCharsets;

/**
 * 用于扩展序列化、反序列化算法
 */

public interface Serializer {

    // 反序列化方法
    <T> T deserialize(Class<T> clazz, byte[] bytes);

    // 序列化方法
    <T> byte[] serialize(T object);

    //枚举+内部类
    enum Algorithm implements Serializer {

        Java {
            @Override
            public <T> T deserialize(Class<T> clazz, byte[] bytes) {
                try {
                    ObjectInputStream ois = new ObjectInputStream(new ByteArrayInputStream(bytes));
                    return (T) ois.readObject();
                } catch (IOException | ClassNotFoundException e) {
                    throw new RuntimeException("反序列化失败", e);
                }
            }

            @Override
            public <T> byte[] serialize(T object) {
                try {
                    ByteArrayOutputStream bos = new ByteArrayOutputStream();
                    ObjectOutputStream oos = new ObjectOutputStream(bos);
                    oos.writeObject(object);
                    return bos.toByteArray();
                } catch (IOException e) {
                    throw new RuntimeException("序列化失败", e);
                }
            }
        },

        Json {//将对象转化为json之后再转化诶字节数组进行传输
            @Override
            public <T> T deserialize(Class<T> clazz, byte[] bytes) {
                //字节数组转clazz类型


                String json=new String(bytes,StandardCharsets.UTF_8);//将字节数组转化为json字符串
                //将json 字符串转化为对象
                ObjectMapper objectMapper=new ObjectMapper();
                try {
                    T t = objectMapper.readValue(json, clazz);
                    return t;
                } catch (JsonProcessingException e) {

                    e.printStackTrace();
                    throw new RuntimeException("反序列化失败",e);
                }

            }

            @Override
            public <T> byte[] serialize(T object) {
                //T对象转字节数组
                try {
                    ObjectMapper objectMapper=new ObjectMapper();
                    String json = objectMapper.writeValueAsString(object);
                    return json.getBytes();
                } catch (JsonProcessingException e) {
                    throw new RuntimeException("序列化失败",e);
                }
            }
        }
    }

}