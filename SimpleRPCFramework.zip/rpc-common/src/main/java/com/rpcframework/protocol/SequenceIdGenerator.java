package com.rpcframework.protocol;

import java.util.concurrent.atomic.AtomicInteger;

//用于生成序列号
public abstract class SequenceIdGenerator {
    private static final AtomicInteger id = new AtomicInteger();

    public static int nextId() {
        return id.incrementAndGet();
    }
}
