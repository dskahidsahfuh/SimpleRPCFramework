package com.rpcframework.protocol;

import com.rpcframework.config.Config;
import com.rpcframework.message.Message;
import io.netty.buffer.ByteBuf;
import io.netty.channel.ChannelHandler;
import io.netty.channel.ChannelHandlerContext;
import io.netty.handler.codec.ByteToMessageCodec;
import io.netty.handler.codec.MessageToMessageCodec;
import lombok.extern.slf4j.Slf4j;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.List;

//自定义消息 编解码器   编码：Message==>ByteBuf(网络中传输)  解码相反
@Slf4j
@ChannelHandler.Sharable
/**
 * 必须和 LengthFieldBasedFrameDecoder 一起使用，确保接到的 ByteBuf 消息是完整的
 */
public class MessageCodec  extends MessageToMessageCodec<ByteBuf, Message> {

    @Override
    protected void encode(ChannelHandlerContext ctx, Message message, List<Object> list) throws Exception {
        ByteBuf out = ctx.alloc().buffer();//根据自定义协议封装消息
        //前16个字节是消息头
        //4个字节魔数：默认1 2 3 4
        out.writeBytes(new byte[]{1,2,3,4});

        //1个字节版本号

        out.writeByte(1);
        //1个字节 序列方式  jdk 1 | json 2  ,根据配置文件选择

        out.writeByte( Config.getSerializerAlgorithm().ordinal());

        //1个字节 指令类型

        out.writeByte(message.getMessageType());
        //4个字节 序列号
        out.writeInt(message.getSequenceId());

        //1字节  填充 无意义

        out.writeByte(0xff);//填充个16进制进去
        //4字节消息长度


        byte[] bytes = Config.getSerializerAlgorithm().serialize(message);
        out.writeInt(bytes.length);
        //写入内容
        out.writeBytes(bytes);

        list.add(out);

    }

    @Override
    protected void decode(ChannelHandlerContext ctx, ByteBuf in, List<Object> list) throws Exception {

        //读取魔数
        int magicNum = in.readInt();
        //读取版本号
        byte versionId = in.readByte();

        //序列方式
        byte serializerType = in.readByte();

        //指令类型
        byte messageType = in.readByte();

        //序列号
        int sequenceId = in.readInt();
        in.readByte();//一字节填充字段
        int length = in.readInt();//消息长度 4字节

        byte[] bytes = new byte[length];//存储消息正文
        in.readBytes(bytes, 0, length);

        // 找到反序列化算法
        Serializer.Algorithm algorithm = Serializer.Algorithm.values()[serializerType];
        // 确定具体消息类型
        Class<? extends Message> messageClass = Message.getMessageClass(messageType);
        Message message = algorithm.deserialize(messageClass, bytes);

        list.add(message);

    }
}
