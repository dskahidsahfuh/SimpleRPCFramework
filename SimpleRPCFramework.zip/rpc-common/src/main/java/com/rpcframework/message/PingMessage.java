package com.rpcframework.message;

public class PingMessage extends Message {

    private String content;

    public PingMessage() {
    }

    public PingMessage(String content) {
        this.content = content;
    }

    @Override
    public int getMessageType() {
        return PingMessage;
    }

    /**
     * 获取
     * @return content
     */
    public String getContent() {
        return content;
    }

    /**
     * 设置
     * @param content
     */
    public void setContent(String content) {
        this.content = content;
    }

    public String toString() {
        return "PingMessage{content = " + content + "}";
    }
}
