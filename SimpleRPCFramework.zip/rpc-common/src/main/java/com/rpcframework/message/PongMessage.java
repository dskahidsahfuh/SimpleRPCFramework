package com.rpcframework.message;

public class PongMessage extends Message {
    private String content;

    public PongMessage() {
    }

    public PongMessage(String content) {
        this.content = content;
    }

    @Override
    public int getMessageType() {
        return PongMessage;
    }

    /**
     * 获取
     * @return content
     */
    public String getContent() {
        return content;
    }

    /**
     * 设置
     * @param content
     */
    public void setContent(String content) {
        this.content = content;
    }

    public String toString() {
        return "PongMessage{content = " + content + "}";
    }
}
