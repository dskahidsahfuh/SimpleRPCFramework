package com.rpcframework.message;

public class TestMessage extends  Message{
    private String content;

    public TestMessage() {
    }

    public TestMessage(String content) {
        this.content = content;
    }

    @Override
    public int getMessageType() {
        return 1;
    }

    /**
     * 获取
     * @return content
     */
    public String getContent() {
        return content;
    }

    /**
     * 设置
     * @param content
     */
    public void setContent(String content) {
        this.content = content;
    }

    public String toString() {
        return "TestMessage{content = " + content + "}";
    }
}
