package com.rpcframework.exception;

public class SimpleException extends Exception{
    private String message;

    public SimpleException(String message) {
        this.message = message;
    }

    public String getMessage() {
        return message;
    }
}
