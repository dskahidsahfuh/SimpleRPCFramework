package com.rpcframework.zookeeper;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class ConfigLoader {
    private static Properties properties;

    static {
        properties = new Properties();
        try {
            InputStream input = ConfigLoader.class.getClassLoader().getResourceAsStream("config.properties");

            properties.load(input);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

    }

    public static String get(String key) {
        return properties.getProperty(key);
    }
}
