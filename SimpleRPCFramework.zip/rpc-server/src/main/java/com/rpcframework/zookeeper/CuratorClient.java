package com.rpcframework.zookeeper;

import org.apache.curator.framework.CuratorFramework;
import org.apache.curator.framework.CuratorFrameworkFactory;
import org.apache.curator.retry.ExponentialBackoffRetry;

public class CuratorClient {
    private static final String ZOOKEEPER_ADDRESS = ConfigLoader.get("zookeeper.connect"); // 从配置文件读取
    private static CuratorFramework client;

    static {
        try {
            client = CuratorFrameworkFactory.newClient(
                    ZOOKEEPER_ADDRESS,
                    new ExponentialBackoffRetry(1000, 3)
            );
            client.start(); // 启动客户端
        } catch (Exception e) {
            e.printStackTrace(); // 打印错误信息
            // 可以在这里处理其他必要的错误逻辑，比如记录日志等
        }
    }

    public static CuratorFramework getInstance() {
        return client;
    }

    public static void close() {
        if (client != null) {
            client.close(); // 关闭客户端连接
        }
    }
}
