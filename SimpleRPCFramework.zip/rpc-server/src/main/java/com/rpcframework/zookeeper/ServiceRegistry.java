package com.rpcframework.zookeeper;
import org.apache.curator.framework.CuratorFramework;
import org.apache.zookeeper.CreateMode;

public class ServiceRegistry {

    private static final String SERVICE_PATH = "/services/";

    public static void registerService(String serviceName, String serviceAddress) {
        try {
            CuratorFramework client = CuratorClient.getInstance(); // 获取 ZooKeeper 客户端连接

            String path = SERVICE_PATH + serviceName + "/" + serviceAddress;

            // 创建服务节点
            if (client.checkExists().forPath(path) == null) {
                client.create()
                        .creatingParentsIfNeeded()
                        .withMode(CreateMode.EPHEMERAL)  // 创建临时节点
                        .forPath(path, serviceAddress.getBytes());

                System.out.println("服务已注册到 ZooKeeper，路径：" + path);
            } else {

                System.out.println("因为zookeeper存在延迟，请稍后重新启动服务" + path);
                throw new RuntimeException("请稍后重新启动服务!");
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
