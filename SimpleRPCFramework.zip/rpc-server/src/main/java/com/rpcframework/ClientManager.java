package com.rpcframework;

import io.netty.channel.Channel;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.ChannelId;
import lombok.extern.slf4j.Slf4j;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
@Slf4j
public class ClientManager {

    // 存储所有连接的客户端
    private final static   Map<ChannelId, Channel> clients = new ConcurrentHashMap<>();

    // 添加客户端
    public static void addClient(Channel channel) {
        ChannelId channelId = channel.id();
        clients.put(channelId, channel);

        log.debug("客户端建立连接:{}" ,channel.remoteAddress());
        log.debug("客户端建立连接:{}" ,channelId);
    }

    // 移除客户端
    public static void removeClient(Channel channel) {
        ChannelId channelId = channel.id();
        clients.remove(channelId);
        System.out.println("客户端断开连接： " + channel.remoteAddress());
        System.out.println("客户端断开连接： " + channelId);
    }

    // 获取所有客户端
    public static Map<ChannelId, Channel> getClients() {
        return clients;
    }

    // 根据 ChannelId 获取特定客户端
    public static Channel getClient(ChannelId channelId) {
        return clients.get(channelId);
    }


}
