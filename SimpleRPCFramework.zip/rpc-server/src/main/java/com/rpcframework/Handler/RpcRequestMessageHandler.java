package com.rpcframework.Handler;

import com.rpcframework.HelloService;
import com.rpcframework.HelloServiceImpl;
import com.rpcframework.ServicesFactory;
import com.rpcframework.exception.SimpleException;
import com.rpcframework.message.RpcRequestMessage;
import com.rpcframework.message.RpcResponseMessage;
import io.netty.channel.ChannelHandler;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.SimpleChannelInboundHandler;
import lombok.extern.java.Log;
import lombok.extern.slf4j.Slf4j;
import sun.plugin2.message.HeartbeatMessage;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

//处理客户端的rpc请求
@Slf4j
@ChannelHandler.Sharable  //没有加上会导致连接失败，因为我们只创建一个，如果不共享会导致连接失败
public class RpcRequestMessageHandler extends SimpleChannelInboundHandler<RpcRequestMessage> {
    //调用客户端想要调用的 方法
    @Override
    protected void channelRead0(ChannelHandlerContext ctx, RpcRequestMessage msg) throws Exception {


        RpcResponseMessage responseMessage=new RpcResponseMessage();
        responseMessage.setSequenceId(msg.getSequenceId());
        //注意：这个不能放在try块里面，否则方法发生异常之后，这条语句不会执行，返回的消息序列号是默认的0
        try {

            String interfaceName = msg.getInterfaceName();
            String methodName = msg.getMethodName();
            Class[] parameterTypes = msg.getParameterTypes();

            log.debug("接收到的消息===》{}",msg);
            Class<?> clazz = Class.forName(interfaceName);
            Object service = ServicesFactory.getService(clazz);

            Method method = service.getClass().getMethod(methodName, parameterTypes);
            Object invoke = method.invoke(service, msg.getParameterValue());//得到方法执行的返回值

            responseMessage.setMessageType(msg.getMessageType());//消息类型
            responseMessage.setReturnValue(invoke);

            log.debug("返回值: {}", invoke);


        } catch (Exception e) {
            e.printStackTrace();
            String error = e.getCause().getMessage();
            responseMessage.setExceptionValue("远程调用错误:"+error);

        }
        ctx.writeAndFlush(responseMessage);




    }


}
