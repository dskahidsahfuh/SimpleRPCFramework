package com.rpcframework.Handler;

import com.rpcframework.message.PingMessage;
import com.rpcframework.message.PongMessage;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.ChannelInboundHandlerAdapter;
import io.netty.channel.SimpleChannelInboundHandler;
import io.netty.handler.timeout.IdleStateEvent;
import lombok.extern.slf4j.Slf4j;
import sun.plugin2.message.HeartbeatMessage;

//心跳处理器
@Slf4j
public class ServerHeartbeatHandler extends SimpleChannelInboundHandler<PingMessage> {
    @Override
    protected void channelRead0(ChannelHandlerContext ctx, PingMessage pingMessage) throws Exception {
        //返回响应
        log.debug("收到ping消息：{}",ctx.channel().remoteAddress());
        PongMessage pongMessage=new PongMessage("服务端心跳"+ctx.channel().id()+"==>pong");

        log.debug("回复pong消息：{}",ctx.channel().remoteAddress());
        ctx.writeAndFlush(pongMessage);
    }


    @Override
    public void userEventTriggered(ChannelHandlerContext ctx, Object evt) throws Exception {
        // 处理空闲事件，断开连接
        if (evt instanceof IdleStateEvent) {
          log.debug("10秒没有收到ping指令，关闭连接：{}",ctx.channel().remoteAddress());
            ctx.close(); // 关闭连接
        } else {
            super.userEventTriggered(ctx, evt);
        }

    }


}
