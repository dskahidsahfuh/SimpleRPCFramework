package com.rpcframework.Handler;

import com.rpcframework.ClientManager;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.ChannelInboundHandlerAdapter;
import io.netty.channel.SimpleChannelInboundHandler;
import lombok.extern.slf4j.Slf4j;

@Slf4j
//管理服务端和客户端的连接
public class ConnectionHandler extends ChannelInboundHandlerAdapter {

    @Override
    public void channelActive(ChannelHandlerContext ctx) throws Exception {

        //添加到 客户端集合中
       ClientManager.addClient(ctx.channel());

       log.debug("连接集合==>{}",ctx);


    }

    @Override
    public void channelInactive(ChannelHandlerContext ctx) throws Exception {
        //客户端集合 移除这个channel
        ClientManager.removeClient(ctx.channel());
    }
}
