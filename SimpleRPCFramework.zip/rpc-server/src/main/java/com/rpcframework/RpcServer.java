package com.rpcframework;
import com.rpcframework.Handler.ConnectionHandler;

import com.rpcframework.Handler.RpcRequestMessageHandler;
import com.rpcframework.Handler.ServerHeartbeatHandler;
import com.rpcframework.protocol.MessageCodec;
import com.rpcframework.protocol.ProcotolFrameDecoder;
import com.rpcframework.zookeeper.ServiceRegistry;
import io.netty.bootstrap.ServerBootstrap;
import io.netty.channel.*;
import io.netty.channel.nio.NioEventLoopGroup;
import io.netty.channel.socket.SocketChannel;
import io.netty.channel.socket.nio.NioServerSocketChannel;
import io.netty.handler.logging.LogLevel;
import io.netty.handler.logging.LoggingHandler;
import io.netty.handler.timeout.IdleStateHandler;
import lombok.extern.slf4j.Slf4j;

import java.util.concurrent.TimeUnit;

@Slf4j
public class RpcServer {

    private static final String SERVICE_NAME = "RPCService";

    private static final int RPC_SERVICE_PORT = 10003; // RPC 服务端口
    private static final String SERVICE_ADDRESS = "localhost:"+RPC_SERVICE_PORT; // 替换为实际 IP 和端口
    public static void main(String[] args) throws InterruptedException {
        // 注册服务到 ZooKeeper
        ServiceRegistry.registerService(SERVICE_NAME, SERVICE_ADDRESS);

        // Netty 服务端配置
        NioEventLoopGroup boss = new NioEventLoopGroup();
        NioEventLoopGroup worker = new NioEventLoopGroup();
        LoggingHandler LOGGING_HANDLER = new LoggingHandler(LogLevel.DEBUG);
        MessageCodec MESSAGE_CODEC = new MessageCodec();
        RpcRequestMessageHandler RPC_HANDLER = new RpcRequestMessageHandler();

        try {
            ServerBootstrap serverBootstrap = new ServerBootstrap();
            serverBootstrap.channel(NioServerSocketChannel.class);
            serverBootstrap.group(boss, worker);
            serverBootstrap.childHandler(new ChannelInitializer<SocketChannel>() {
                @Override
                protected void initChannel(SocketChannel ch) throws Exception {
                    ch.pipeline().addLast(new ProcotolFrameDecoder());
                 //   ch.pipeline().addLast(LOGGING_HANDLER);
                    ch.pipeline().addLast(MESSAGE_CODEC);
                    ch.pipeline().addLast(new ConnectionHandler());
                    //10秒没有写出  就会触发这个事件
                    ch.pipeline().addLast(new IdleStateHandler(0, 10, 0, TimeUnit.SECONDS)); // 5秒内无写操作则触发 IdleStateEvent
                    ch.pipeline().addLast(new ServerHeartbeatHandler()); // 心跳处理器
                    ch.pipeline().addLast(RPC_HANDLER);
                }
            });
            Channel channel = serverBootstrap.bind(RPC_SERVICE_PORT).sync().channel();
            channel.closeFuture().sync();
        } catch (InterruptedException e) {
            log.error("server error", e);
        } finally {
            boss.shutdownGracefully();
            worker.shutdownGracefully();
        }
    }
}
