package com.rpcframework;
//提供远程调用的接口和方法
public interface HelloService {
    String sayHello(String name);

    Integer addNum(int a,int b);
}
