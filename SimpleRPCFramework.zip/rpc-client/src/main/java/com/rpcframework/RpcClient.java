package com.rpcframework;

import com.rpcframework.Handler.HeartbeatHandler;
import com.rpcframework.Handler.RpcResponseMessageHandler;
import com.rpcframework.message.RpcRequestMessage;
import com.rpcframework.protocol.MessageCodec;
import com.rpcframework.protocol.ProcotolFrameDecoder;
import com.rpcframework.protocol.SequenceIdGenerator;
import com.rpcframework.zookeeper.LoadBalancer;
import com.rpcframework.zookeeper.ServiceDiscovery;
import io.netty.bootstrap.Bootstrap;
import io.netty.channel.Channel;
import io.netty.channel.ChannelInitializer;
import io.netty.channel.nio.NioEventLoopGroup;
import io.netty.channel.socket.SocketChannel;
import io.netty.channel.socket.nio.NioSocketChannel;
import io.netty.handler.logging.LogLevel;
import io.netty.handler.logging.LoggingHandler;
import io.netty.handler.timeout.IdleStateHandler;
import io.netty.util.concurrent.DefaultPromise;
import lombok.extern.slf4j.Slf4j;
import org.apache.curator.framework.CuratorFramework;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

import static com.rpcframework.Handler.RpcResponseMessageHandler.PROMISES;

@Slf4j
public class RpcClient {
    public static final List<Channel> channels = new ArrayList<>(); // 存储多个 Channel
    private static int activeChannels = 0; // 记录活跃连接数  ，避免因为一个服务端断开 导致整个程序停止

    private static final Object LOCK = new Object();

    public  static final String SERVICE_NAME = "RPCService"; // 服务名称
    private static CuratorFramework zkClient;
    //public  static Map<Channel,Boolean> receivedPongMap=new HashMap<>();

    public static void main(String[] args) throws InterruptedException {
       /* HelloService helloService = getProxyService(HelloService.class);
        helloService.sayHello("zhangsan");*/
        test();

    }

    private static void test() throws InterruptedException {
        // 吞吐量统计
        final AtomicInteger successCount = new AtomicInteger(0); // 使用原子变量
        final long startTime = System.currentTimeMillis(); // 记录开始时间

        // 启动一个线程来收集吞吐量数据
        Thread throughputCollector = new Thread(() -> {
            while (true) {
                long elapsedTime = System.currentTimeMillis() - startTime;
                if (elapsedTime >= 20000) { // 5秒
                    System.out.println("20秒内的吞吐量: " + successCount.get() + " 请求");
                    break; // 退出循环
                }
                System.out.println("当前吞吐量: " + successCount.get() + " 请求"); // 每秒打印当前成功请求计数
                try {
                    Thread.sleep(1000); // 每秒打印一次
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                }
            }
        });
        throughputCollector.start();

        // 模拟多次调用
        HelloService helloService = getProxyService(HelloService.class);
        for (int i = 0; i < 100000; i++) {
            try {
                helloService.sayHello("zhangsan");
                successCount.incrementAndGet(); // 增加成功请求计数
            } catch (Exception e) {
                log.error("请求失败", e);
            }
        }

        // 等待吞吐量线程结束
        throughputCollector.join();
    }

    //动态代理
    private static <T> T getProxyService(Class<T> serviceClass) {
        ClassLoader classLoader = serviceClass.getClassLoader();
        Class[] interfaces = new Class[]{serviceClass};
        return (T) Proxy.newProxyInstance(classLoader, interfaces, new InvocationHandler() {
            @Override
            public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
                int sequenceId = SequenceIdGenerator.nextId();
                RpcRequestMessage requestMessage = new RpcRequestMessage(
                        sequenceId,
                        serviceClass.getName(),
                        method.getName(),
                        method.getReturnType(),
                        method.getParameterTypes(),
                        args
                );

                Channel channel = getChannel();
                DefaultPromise<Object> promise = new DefaultPromise<>(channel.eventLoop());
                PROMISES.put(sequenceId, promise);

                int maxRetries = 3; // 最大重试次数
                int attempt = 0; // 当前尝试次数

                while (attempt < maxRetries) {
                    try {
                        channel.writeAndFlush(requestMessage).sync(); // 发送请求并等待结果
                        promise.await(); // 等待结果

                        if (promise.isSuccess()) {
                            return promise.getNow(); // 返回成功结果
                        } else {
                            throw new RuntimeException(promise.cause()); // 抛出异常
                        }
                    } catch (Exception e) {
                        attempt++; // 增加尝试次数
                        if (attempt >= maxRetries) {
                            throw new RuntimeException("请求失败，达到最大重试次数", e); // 达到最大重试次数，抛出异常
                        }

                        // 可选：根据策略决定重试间隔
                        Thread.sleep(1000 * attempt); // 例如：每次重试间隔增加
                    }
                }

                return null; // 这行代码不会到达
            }

        });
    }

    private static Channel getChannel() {
        synchronized (LOCK) {
            // 如果没有连接，则初始化通道
            if (channels.isEmpty()) {
                initChannel(); // 这里会建立连接
            }

            //通过负载均衡获取到  具体的channel  具体的服务端
            Channel channel = LoadBalancer.getChannel_LoadBalancer(channels);



            return channel; // 如果没有可用连接
        }
    }

    private static void initChannel() {
        NioEventLoopGroup group = new NioEventLoopGroup();
        MessageCodec messageCodec = new MessageCodec();
        LoggingHandler loggingHandler = new LoggingHandler(LogLevel.DEBUG);
        RpcResponseMessageHandler rpcResponseMessageHandler = new RpcResponseMessageHandler();

        Bootstrap bootstrap = new Bootstrap();
        bootstrap.group(group)
                .channel(NioSocketChannel.class)
                .handler(new ChannelInitializer<SocketChannel>() {
                    @Override
                    protected void initChannel(SocketChannel ch) throws Exception {
                        ch.pipeline().addLast(new ProcotolFrameDecoder());
                     //   ch.pipeline().addLast(loggingHandler);
                        ch.pipeline().addLast(messageCodec);
                        //这里设置为6秒触发，如果是5秒的话，会和心跳处理器 发出两次ping
                        //下面两个处理器得同时生效才会触发心跳机制
                        ch.pipeline().addLast(new IdleStateHandler(0, 6, 0, TimeUnit.SECONDS)); // 5秒内无写操作则发送心跳
                       ch.pipeline().addLast(new HeartbeatHandler()); // 心跳处理器
                        ch.pipeline().addLast(rpcResponseMessageHandler);
                    }
                });

        try {
            // 从 ZooKeeper 获取服务地址  返回所有服务端的地址和端口
            List<String[]> addressList = ServiceDiscovery.getAllAddresses(SERVICE_NAME);

            for (String[] addressAndPort : addressList) {
                String host = addressAndPort[0];
                int port = Integer.parseInt(addressAndPort[1]);

                Channel channel = bootstrap.connect(host, port).sync().channel();
                channels.add(channel); // 将每个连接添加到集合中

                activeChannels++;// 连接成功，增加计数
                channel.closeFuture().addListener(future -> {
                    activeChannels--;// 断开连接，计数减一
                    if(activeChannels==0){
                        group.shutdownGracefully();
                    }

                });
            }
        } catch (Exception e) {
            log.error("client error", e);
        }
    }
}
