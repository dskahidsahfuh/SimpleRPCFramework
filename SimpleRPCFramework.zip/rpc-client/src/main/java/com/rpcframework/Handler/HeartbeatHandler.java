package com.rpcframework.Handler;

import com.rpcframework.message.PingMessage;
import com.rpcframework.message.PongMessage;
import io.netty.channel.Channel;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.SimpleChannelInboundHandler;
import io.netty.handler.timeout.IdleState;
import io.netty.handler.timeout.IdleStateEvent;
import io.netty.util.concurrent.ScheduledFuture;
import lombok.extern.slf4j.Slf4j;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.TimeUnit;



@Slf4j
public class HeartbeatHandler extends SimpleChannelInboundHandler<PongMessage> {

    private ScheduledFuture<?> pingSchedule;//是用于管理一个定时任务的句柄  用来控制或取消定时任务
    private static final int PING_INTERVAL = 5; // 发送 ping 的间隔时间（秒）
    private static final int PONG_TIMEOUT = 3; // 等待 pong 响应的超时时间（秒）
    private boolean receivedPong=false;//发送ping 命令后有没有收到pong回复     每个连接都单独拥有

    // 如果value为true,表示发送ping之后收到pong

    @Override
    public void channelActive(ChannelHandlerContext ctx) throws Exception {
       // receivedPongMap.put(ctx.channel(),false);

        startPingSchedule(ctx); // 连接激活后，开始 ping 调度

    }

    @Override
    protected void channelRead0(ChannelHandlerContext ctx, PongMessage pongMessage) throws Exception {
        log.info("收到了 pong 消息来自: {}", ctx.channel().remoteAddress());

        receivedPong=true;
      /*  if(receivedPongMap.containsKey(ctx.channel())){
            //如果有这个连接   ,将回应标志改为true
            receivedPongMap.put(ctx.channel(),true);
        }*/
    }

    @Override
    public void userEventTriggered(ChannelHandlerContext ctx, Object evt) throws Exception {
        if (evt instanceof IdleStateEvent) {
            IdleStateEvent event = (IdleStateEvent) evt;
            if (event.state() == IdleState.WRITER_IDLE) {
                sendPing(ctx); // 在 WRITER_IDLE 事件上发送 ping


            }
        } else {
            super.userEventTriggered(ctx, evt);
        }
    }

    private void startPingSchedule(ChannelHandlerContext ctx) {
        //参数1：定期执行的任务   参数2：第一个任务在多久后执行    参数3：任务执行的时间间隔   参数4：时间单位
        pingSchedule = ctx.executor().scheduleWithFixedDelay(() -> sendPing(ctx), 0, PING_INTERVAL, TimeUnit.SECONDS);
    }

    private void sendPing(ChannelHandlerContext ctx) {
        log.debug("发送 ping 指令");

        PingMessage pingMessage = new PingMessage("客户端 " + ctx.channel().id() + " ==> ping");
        ctx.writeAndFlush(pingMessage);

        // 发送后重置 receivedPong

        receivedPong=false;
        // 在发送 Ping 后设置 PONG_TIMEOUT 超时任务等待 Pong 响应
        ctx.executor().schedule(() -> {
            if (!receivedPong&& ctx.channel().isActive()) {//检查是否收到pong和连接是否存在
                log.warn("3 秒没有收到 pong 指令，关闭连接: {}", ctx.channel().remoteAddress());
                ctx.close(); // 关闭连接
                if (pingSchedule != null) {
                    pingSchedule.cancel(false);
                }
            }
        }, PONG_TIMEOUT, TimeUnit.SECONDS);
    }



    @Override
    public void exceptionCaught(ChannelHandlerContext ctx, Throwable cause) throws Exception {
        log.error("心跳检查期间发生异常", cause);
        //cleanup(ctx);
    }

    @Override
    public void channelInactive(ChannelHandlerContext ctx) throws Exception {
        log.debug("断开和服务端的连接：{}",ctx.channel().remoteAddress());
        cleanup(ctx);
        super.channelInactive(ctx);
    }

    private void cleanup(ChannelHandlerContext ctx) {
        if (pingSchedule != null) {
            pingSchedule.cancel(false);
        }
        log.info("清理连接: {}", ctx.channel().remoteAddress());
    }
}
