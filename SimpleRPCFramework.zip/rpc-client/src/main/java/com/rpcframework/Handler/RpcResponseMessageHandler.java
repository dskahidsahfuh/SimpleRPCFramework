package com.rpcframework.Handler;

import com.rpcframework.message.RpcResponseMessage;
import io.netty.channel.ChannelHandler;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.SimpleChannelInboundHandler;
import io.netty.util.concurrent.Promise;
import lombok.extern.slf4j.Slf4j;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
@ChannelHandler.Sharable//这里的map集合没有线程安全问题，所以可以用这个注解
@Slf4j
public class RpcResponseMessageHandler extends SimpleChannelInboundHandler<RpcResponseMessage> {
    //key是消息的序列号     value是消息内容
    public static final Map<Integer, Promise<Object>> PROMISES = new ConcurrentHashMap<>();
    @Override
    protected void channelRead0(ChannelHandlerContext ctx, RpcResponseMessage msg) throws Exception {
        //执行到这个方法，意味着已经从服务端拿到远程调用的结果了


        Promise<Object> promise = PROMISES.remove(msg.getSequenceId());



        if(promise!=null){  //做个非空判断，以免系统异常
            Object returnValue = msg.getReturnValue();
            String exceptionValue = msg.getExceptionValue();//错误信息

            //这里约定错误信息为空的话 就代表调用成功
            if(exceptionValue==null){
                promise.setSuccess(returnValue);
            }else{
                promise.setFailure(new RuntimeException(exceptionValue));
            }
        }


    }
}
