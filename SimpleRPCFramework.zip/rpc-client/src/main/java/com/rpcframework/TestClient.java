package com.rpcframework;

import com.rpcframework.message.TestMessage;
import com.rpcframework.protocol.MessageCodec;
import com.rpcframework.protocol.ProcotolFrameDecoder;
import io.netty.bootstrap.Bootstrap;
import io.netty.channel.Channel;
import io.netty.channel.ChannelFuture;
import io.netty.channel.ChannelInitializer;
import io.netty.channel.nio.NioEventLoopGroup;
import io.netty.channel.socket.SocketChannel;
import io.netty.channel.socket.nio.NioSocketChannel;
import io.netty.handler.logging.LoggingHandler;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class TestClient {
    public static void main(String[] args) throws InterruptedException {
        NioEventLoopGroup group = new NioEventLoopGroup();
        MessageCodec messageCodec=new MessageCodec();
        LoggingHandler loggingHandler=new LoggingHandler();
        Bootstrap bootstrap = new Bootstrap();
        ChannelFuture channelFuture = bootstrap.group(group)
                .channel(NioSocketChannel.class)
                .handler(new ChannelInitializer<SocketChannel>() {
                    @Override
                    protected void initChannel(SocketChannel ch) throws Exception {
                        ch.pipeline().addLast(new ProcotolFrameDecoder());
                       // ch.pipeline().addLast(new StringEncoder());
                        ch.pipeline().addLast(messageCodec);
                        ch.pipeline().addLast(loggingHandler);


                    }
                }).connect("localhost", 9090).sync();

        Channel channel = channelFuture.channel();
        TestMessage message=new TestMessage("测试消息");
        channel.writeAndFlush(message);
    }
}
