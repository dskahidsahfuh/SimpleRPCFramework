package com.rpcframework.zookeeper;

import org.apache.zookeeper.*;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class ServiceDiscovery {
    private final String zkAddress;
    private static final String ZK_ADDRESS = "localhost:2181"; // ZooKeeper 地址
    public ServiceDiscovery(String zkAddress) {
        this.zkAddress = zkAddress;
    }

    // 根据服务名返回所有服务的地址和端口（静态方法）
    public static List<String[]> getAllAddresses(String serviceName) {
        List<String[]> addresses = new ArrayList<>();
        ZooKeeper zooKeeper = null;
        try {
            zooKeeper = new ZooKeeper(ZK_ADDRESS, 3000, null);
            String servicePath = "/services/" + serviceName;
            List<String> children = zooKeeper.getChildren(servicePath, false);
            for (String child : children) {
                String childPath = servicePath + "/" + child;
                byte[] data = zooKeeper.getData(childPath, false, null);
                String address = new String(data);
                String[] addressParts = address.split(":"); // 假设地址格式为 "host:port"
                addresses.add(addressParts);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (zooKeeper != null) {
                try {
                    zooKeeper.close(); // 关闭连接
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }
        return addresses;
    }

    // 从 ZooKeeper 获取一个服务地址（用于负载均衡）
    public String discover(String serviceName) {
        try {
            ZooKeeper zooKeeper = new ZooKeeper(zkAddress, 3000, null);
            String servicePath = "/services/" + serviceName;
            List<String> children = zooKeeper.getChildren(servicePath, false);
            if (children.size() > 0) {
                // 返回第一个服务地址
                String serviceAddress = children.get(0);
                return serviceAddress;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
}
