package com.rpcframework.zookeeper;

import io.netty.channel.Channel;
import org.apache.curator.framework.CuratorFramework;
import java.util.List;
import java.util.Random;
import java.util.concurrent.atomic.AtomicInteger;
//负载均衡工具类
public class LoadBalancer {


    private static CuratorFramework zkClient;
    private static final String LoadBalancingStrategy=ConfigLoader.get("rpc.LoadBalancerConfig");

    private static final AtomicInteger index = new AtomicInteger(0);


    //根据配置文件信息，选择channel
    public static final Channel getChannel_LoadBalancer(List<Channel> channels){
        Random r=new Random();
        if(LoadBalancingStrategy==null||"Random".equals(LoadBalancingStrategy.trim())){
            //默认是随机
            return channels.get(r.nextInt(channels.size()));//返回随机channel
        }else if("RoundRobin".equals(LoadBalancingStrategy.trim())){
            int i = index.getAndIncrement() % channels.size();
            Channel channel = channels.get(i);
            return channel;
        }else{
            throw new IllegalArgumentException("Invalid Load Balancing Strategy: " + LoadBalancingStrategy);
        }
    }

}
