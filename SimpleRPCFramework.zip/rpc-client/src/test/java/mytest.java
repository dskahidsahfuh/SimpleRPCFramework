import com.rpcframework.protocol.MessageCodec;

public class mytest {
    public static void main(String[] args) {

    }
}
